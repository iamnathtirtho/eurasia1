<?php

session_start();

session_destroy();
?>

<script>

window.location="admin_login.php";

</script>
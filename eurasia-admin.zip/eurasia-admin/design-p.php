<?php
if (isset($_POST['submit'])) {
	if ($_POST['id']=="") {
		$error_msg['name']="Name is required";	# code...
	}
	# code...



    $description=$_POST['description'];
	if (empty($roll)) {
		$error_msg['description']="Description is required";	# code...
	}

	}
	# code...




?>